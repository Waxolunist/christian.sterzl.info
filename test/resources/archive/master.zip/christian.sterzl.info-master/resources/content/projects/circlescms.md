---
author: Christian Sterzl
time: 2013
name: CirclesCMS
tags: web jquery angularjs javascript nodejs express socketstream html5
site: https://github.com/Waxolunist/circlescms
summary: CirclesCMS is an easy to use and easy to program, single page html5 content management system and blog engine built around websockets and angularjs.
---

# CirclesCMS


