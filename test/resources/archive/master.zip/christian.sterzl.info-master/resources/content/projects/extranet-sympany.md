---
author: Christian Sterzl
time: 2009 - 2012
name: Extranet Sympany
tags: web java cq5 security maven jquery weblogic
site: http://login.sympany.ch
summary: A portal for intermediaries and brokers of Sympany, based on Adobe CQ5, providing informations about their contracts and accounts.
---

# Extranet Sympany


