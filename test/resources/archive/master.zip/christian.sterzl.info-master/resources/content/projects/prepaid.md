---
author: Christian Sterzl
time: 2005 - 2007
name: Europay Prepaid
tags: web java plsql websphere
site: http://www.prepaid-karten.at/web/content/de/Home/ueber_prepaid/index.html
summary: A web application to manage and sell prepaid credit cards for MasterCard.
---

# Europay Prepaid
