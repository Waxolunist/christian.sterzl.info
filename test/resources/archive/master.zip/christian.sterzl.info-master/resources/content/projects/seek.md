---
author: Christian Sterzl
time: 2007 - 2009
name: SEEK!
tags: web java .net
summary: A web application for helping human resources departements in their daily tasks.
---

# SEEK!


