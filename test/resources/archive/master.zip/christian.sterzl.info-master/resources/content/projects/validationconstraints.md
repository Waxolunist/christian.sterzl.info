---
author: Christian Sterzl
time: 2012 - 2013
name: Validationconstraints
tags: java beanvalidation
site: https://waxolunist.github.io/validationconstraints
summary: JSR-303 Validators to validate a daterange and other constraints.
---

# Validationconstraints


