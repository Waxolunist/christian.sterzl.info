define([
  './ccctrl',
  './rootctrl',
  './tagcloud'
], function () {});
