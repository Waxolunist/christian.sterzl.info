define([
  './ccactive',
  './tagcloud',
  './carousel',
  './compiletemplate'
], function () {});
